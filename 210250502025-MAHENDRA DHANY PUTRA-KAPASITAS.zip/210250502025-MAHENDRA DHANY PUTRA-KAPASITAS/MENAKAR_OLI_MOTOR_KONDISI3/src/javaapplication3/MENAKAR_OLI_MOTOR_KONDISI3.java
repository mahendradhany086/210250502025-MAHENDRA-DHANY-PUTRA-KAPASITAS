/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication3;

import java.util.Scanner;

/**
 *
 * @author Mahendra Dhani Putra
 */
public class MENAKAR_OLI_MOTOR_KONDISI3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int kapasitas ;
       
       kapasitas = 1300;
   
        if (kapasitas>=500&kapasitas<=900) {
            System.out.println("revo");}
        else if (kapasitas>=900&kapasitas<=1200) {
            System.out.println("vixion");}
        else if (kapasitas>=1200&kapasitas<=1400) {
            System.out.println("klx");}
        else {
            System.out.println("moge");}
    }     
    }
